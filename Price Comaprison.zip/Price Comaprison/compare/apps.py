from django.apps import AppConfig


class CompareConfig(AppConfig):
    name = 'compare'
